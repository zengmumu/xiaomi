import React, { Component } from 'react';
import './App.css';
// 01 导入路由需要的组件
import { BrowserRouter as Router, Route, Link,NavLink,Switch} from "react-router-dom";
// 05 导入路由所需要的组件
import Home from './views/Home'
import Produce from './views/Produce'
import Detail from './views/Detail'
class App extends Component {
  render() {
    return (
      <div className="App">
{/* 02 配置总路由 Router */}
        <Router>
          <div>
{/* 03 配置导航 */}
            <Link to="/">首页</Link> | <Link to="/about">关于</Link> |
            <Link to="/produce/1">产品1</Link> |  <Link to="/produce/abc">产品abc</Link>|
            <Link to="/detail">详情</Link> |
            <hr/> 
            <NavLink to="/" exact>首页</NavLink> | <NavLink to="/about">关于</NavLink> |
            <NavLink to="/produce/1">产品1</NavLink> |  <NavLink to="/produce/abc">产品abc</NavLink>|
            <NavLink to="/detail">详情</NavLink> |Nav
            <hr/>
            <div>
{/* 04 配置路 当浏览器进入到path这个地址时候 切换组件为 Home */}
{/* exact path 必须完全配置 */}
            <Switch>
              <Route path="/" exact component={Home}></Route>
              <Route path="/about" component={About}></Route>
              <Route path="/produce/:id" component={Produce}></Route>
              <Route path="/detail" component={Detail}></Route>
              <Route component={NoMatch}></Route>
              {/* 空的path 能匹配任何的地址 */}
            </Switch>
            </div>         
          </div>      
        </Router>
      </div>
    );
  }
}

export default App;
// 组件的快捷书写方式
function About(){
  return <h1>我是About页面</h1>
}
function NoMatch({location,history}){
  return ( <div>
    <h1>你的页面被外星人偷走了，找不到404</h1>
    <p>{location.pathname}</p>
    <button onClick={()=>{history.push("/")}}>回首页</button>
  </div> )
}
